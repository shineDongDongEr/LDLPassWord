//
//  DLPasswordVerifyView.h
//  DLPassword
//
//  Created by laidongling on 16/8/31.
//  Copyright © 2016年 LaiDongling. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLPasswordVerifyView : UIView

@property (strong, nonatomic) UITextField *passTextField;

//添加验证密码框;
- (void)addVerifyView;

@end
