//
//  ViewController.m
//  DLPassword
//
//  Created by laidongling on 16/8/31.
//  Copyright © 2016年 LaiDongling. All rights reserved.
//

#import "ViewController.h"
#import "DLPasswordVerifyView.h"

#define  DLScreenW [UIScreen mainScreen].bounds.size.width
#define  DLScreenH [UIScreen mainScreen].bounds.size.height

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *cardNumberView;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@property (weak, nonatomic) IBOutlet DLPasswordVerifyView *passwordView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupStyle];
    
}

- (void)setupStyle
{
    self.loginBtn.layer.cornerRadius = 5.0f;
    self.cardNumberView.backgroundColor = [UIColor yellowColor];
    

    UIView *view = [[DLPasswordVerifyView alloc]initWithFrame:CGRectMake(0, 0, DLScreenW - 24, (DLScreenW - 24)/7)];
    view.backgroundColor = [UIColor orangeColor];
    
    [self.passwordView addSubview:view];
    
    
   
   

}
@end
