
//
//  CircleView.m
//  DLPassword
//
//  Created by laidongling on 16/9/1.
//  Copyright © 2016年 LaiDongling. All rights reserved.
//

#import "CircleView.h"
#import "UIView+Frame.h"

@implementation CircleView

-(void)drawRect:(CGRect)rect
{
    CGPoint center = CGPointMake(rect.size.width * 0.5, rect.size.height * 0.5);
    CGFloat radius = rect.size.width * 0.5 -0.5;
    UIBezierPath *clipPath = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:-M_PI*2 endAngle:0 clockwise:YES];
    [[UIColor blackColor] set];
    [clipPath fill];
    
}
@end
