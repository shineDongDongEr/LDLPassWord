//
//  DLPasswordVerifyView.m
//  DLPassword
//
//  Created by laidongling on 16/8/31.
//  Copyright © 2016年 LaiDongling. All rights reserved.
//

#import "DLPasswordVerifyView.h"
#import "UIView+Frame.h"
#import "CircleView.h"

@interface DLPasswordVerifyView()<UITextFieldDelegate>
@property(nonatomic,strong)NSMutableArray *passLayers;

@end

@implementation DLPasswordVerifyView
- (NSMutableArray *)passLayers
{
    if (!_passLayers) {
        _passLayers = [NSMutableArray array];
    }
    return _passLayers;

}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //添加验证框;
        [self addVerifyView];
        
    }
    return self;
}
-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        
    }
    return self;

}

- (void)addVerifyView
{
    //画视图;
    [self drawView];
    //添加点击;
    [self addClik];
 
    
}
- (void)drawView
{
    CGFloat W = self.frame.size.width / 6;      //每个小格子宽度;
    CGFloat PW = 15;                            //每个点的直径;
    CGFloat H = self.bounds.size.height;        //每个小格子高度;
    //添加5条分割线;
    for (int i = 1 ; i <= 6; i++) {
        
        CALayer *layer = [CALayer layer];
        
        layer.borderWidth = 0.5;
        
        layer.borderColor = [UIColor lightGrayColor].CGColor;
        
        layer.frame = CGRectMake(i * W, 0, 0.5, H);
        
        [self.layer addSublayer:layer];
        
    }
    
    //添加6个黑点;
    for (int i = 1 ; i <= 6; i++) {
        
        CircleView *point = [[CircleView alloc]initWithFrame:CGRectMake(W*i - W/2 - PW/2, H/2 - PW/2, PW,PW)];
        point.backgroundColor = [UIColor clearColor];
        [self.passLayers addObject:point];
        [self addSubview:self.passTextField];
        [self addSubview:point];
        point.hidden = YES;
    }

}
- (void)addClik
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(textViewDidClik)];
    [self addGestureRecognizer:tap];

}

- (void)textViewDidClik
{
    
    [self.passTextField becomeFirstResponder];

}

-(UITextField *)passTextField
{
    if (!_passTextField) {
        _passTextField = [[UITextField alloc]initWithFrame:CGRectZero];
        _passTextField.keyboardType = UIKeyboardTypeNumberPad;
        _passTextField.delegate = self;
        
    }
    return _passTextField;

}

#pragma mark - UITextFieldDelegate----------

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (self.passTextField == textField) {
        
        NSString *futureString = [self changeCharactersInRange:range replacementString:string];
        
        NSLog(@"=================%@",futureString);
        
        if (futureString.length <= 6) {
            
            
            int i = 0;
            
            for (UIView *point in self.passLayers) {
                
                point.hidden = YES;
                
                if ( i < futureString.length ) {
                    
                    point.hidden = NO;
                }
                
                i++;
            }
            
            return YES;
            
        }else{
            
            return NO;
            
        }
    }

    return YES;
}

// 调用textField(textField: UITextField, shouldChangeCharactersInRange时，第一个输入的字符不会进入前面一个方法，此方法就是将第一个字符插入[futureString insertString:string atIndex:range.location]
- (NSString *) changeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString * futureString = [NSMutableString stringWithString:self.passTextField.text];
    //每次添加密码，range.length 都== 0;删除的时候length == 1;
    if (range.length == 0) {
        //插入字符;
        [futureString insertString:string atIndex:range.location];
    } else {
        //删除字符;
        [futureString deleteCharactersInRange:range];
    }
    
    return futureString;
}



@end
